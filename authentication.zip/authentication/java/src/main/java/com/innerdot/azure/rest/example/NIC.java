/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innerdot.azure.rest.example;

//import net.minidev.json.JSONArray;
//import net.minidev.json.JSONObject;
//
///**
// *
// * @author Osura
// */
//public class NIC {
//    
//    String jst = null;
//    
//             JSONObject root = new JSONObject(jst);
//        JSONArray sportsArray = root.getJSONArray();
//        // now get the first element:
//        JSONObject firstSport = sportsArray.getJSONObject(0);
//        // and so on
//        String name = firstSport.getString("name"); // basketball
//        int id = firstSport.getInt("id"); // 40
//        JSONArray leaguesArray = firstSport.getJSONArray("leagues");
//}
